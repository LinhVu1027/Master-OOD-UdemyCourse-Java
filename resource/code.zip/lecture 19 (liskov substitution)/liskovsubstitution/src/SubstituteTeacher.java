
public class SubstituteTeacher extends SchoolStaff{


}
