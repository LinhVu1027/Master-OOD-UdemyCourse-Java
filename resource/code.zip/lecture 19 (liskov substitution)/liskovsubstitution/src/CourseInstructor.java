
public interface CourseInstructor {
	public void teach();
}
